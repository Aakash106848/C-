﻿namespace NWindMVC.Models;
using System.Linq;
using System.Web;
public class RepositoryOrders
{
    private NorthwindContext _context;
    public RepositoryOrders(NorthwindContext context) 
    {
        _context = context;
    }
    public List<Order> AllOrders() 
    {
        return _context.Orders.ToList();
    }
    public List<Order> ListAllOrders() 
    {
        return _context.Orders.ToList();
    }
    public Order FindOrderById(int id)
    {

        Order order = _context.Orders.Find(id);
        return order;
    }
    public List<Order> GetOrderId() 
    {
        List<Order> orderIds = _context.Orders
     .Select(o => new Order { OrderId = o.OrderId })
     .ToList();
        return orderIds ;   
    }
    public Order? FindOrderByCustomerId(string Customerid)
    {
        
        var order = _context.Orders.Find(Customerid);
        return order;
    }
    public List<OrderDetail> FindOrderDetailByOrderId(int id) 
    {
        return null;
    }
    public Product GetProductId(int productid) 
    {
        return null;
    }
}
